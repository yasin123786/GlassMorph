# Claymorphism + Glassmorphism

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/ExwRvVN](https://codepen.io/TheMOZZARELLA/pen/ExwRvVN).

Card combining claymorphism and glassmorphism.