//showing the box modal
function openModal(){
  const open = document.getElementById("card");
  open.style.display="flex";
  open.style.width="300px";
};

//close the box modal
function closeModal(){
  const close = document.getElementById("card");
  close.style.display="none";
};