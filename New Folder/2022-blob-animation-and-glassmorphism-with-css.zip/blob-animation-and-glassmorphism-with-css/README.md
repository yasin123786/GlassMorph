# Blob Animation And Glassmorphism with CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/thedevenv/pen/JjrXayd](https://codepen.io/thedevenv/pen/JjrXayd).

Blob css animation and glassmorphism. Cool Blob Gradient animation with css