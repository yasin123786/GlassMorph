# Glassmorphism: Simple Card UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/_rahul/pen/NWXjOXW](https://codepen.io/_rahul/pen/NWXjOXW).

