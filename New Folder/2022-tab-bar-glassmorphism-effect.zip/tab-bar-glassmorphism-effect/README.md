# Tab-bar (Glassmorphism Effect) 

A Pen created on CodePen.io. Original URL: [https://codepen.io/fydsa/pen/VwWXdZm](https://codepen.io/fydsa/pen/VwWXdZm).

Made an animated tab bar with pure js, css, and html in glass-morphism style.