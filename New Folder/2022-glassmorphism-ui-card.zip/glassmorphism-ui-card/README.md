# Glassmorphism UI Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/Coding-Artist/pen/jOMwVYQ](https://codepen.io/Coding-Artist/pen/jOMwVYQ).

